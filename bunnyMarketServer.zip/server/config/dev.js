module.exports = {
    mongoURI:'mongodb+srv://admin:admin1111@boilerplate.mdq4a.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}