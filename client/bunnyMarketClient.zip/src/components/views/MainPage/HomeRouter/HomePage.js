import React from 'react'

function HomePage() {
    return (
        <div>
            hihi
        </div>
    )
}

export default HomePage
