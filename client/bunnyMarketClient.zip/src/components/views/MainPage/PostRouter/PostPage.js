import React from 'react'

function PostPage() {
    return (
        <div>
            postPage
        </div>
    )
}

export default PostPage
