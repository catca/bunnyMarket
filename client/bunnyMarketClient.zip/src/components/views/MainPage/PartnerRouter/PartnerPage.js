import React from 'react'

function PartnerPage() {
    return (
        <div>
            partnerPage
        </div>
    )
}

export default PartnerPage
